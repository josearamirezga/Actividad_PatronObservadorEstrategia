import java.util.*;

public class OrdenarPorFecha implements EstrategiaOrdenamiento {
    @Override
    public void ordenar(List<Tarea> tareas) {
        tareas.sort(Comparator.comparing(Tarea::getFechaEntrega, Comparator.nullsLast(Date::compareTo)));
    }
}
