import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class VentanaPrincipal extends JFrame {
    private JTextField campoNombre;
    private JButton btnContinuar;
    private JPanel panelTareas;
    private GestorDeTareas gestor;
    private VentanaNotificacion notificador;
    private JButton btnPorPrioridad, btnPorFecha, btnPorEstado;
    private JButton[] botonesFiltro;
    private JButton botonActivo = null;

    public VentanaPrincipal(GestorDeTareas gestor) {
        super("Gestor de Tareas");
        this.gestor = gestor;
        this.notificador = new VentanaNotificacion();

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(750, 550);
        gbc.insets = new Insets(10, 10, 10, 10);

        campoNombre = new JTextField(20);
        btnContinuar = new JButton("Continuar");
        panelTareas = new JPanel(new GridLayout(0, 1, 5, 5));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(new JLabel("Ingresar nueva tarea:"), gbc);

        gbc.gridy = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(campoNombre, gbc);

        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        add(btnContinuar, gbc);

        // ===== BOTONES DE ORDENAMIENTO =====
        btnPorPrioridad = new JButton("Ordenar por Prioridad");
        btnPorFecha = new JButton("Ordenar por Fecha");
        btnPorEstado = new JButton("Ordenar por Estatus");

        botonesFiltro = new JButton[]{btnPorPrioridad, btnPorFecha, btnPorEstado};
        for (JButton btn : botonesFiltro) {
            btn.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            btn.setBackground(null);
            btn.setForeground(Color.BLACK);
        }

        JPanel panelBotones = new JPanel(new FlowLayout());
        panelBotones.add(btnPorPrioridad);
        panelBotones.add(btnPorFecha);
        panelBotones.add(btnPorEstado);

        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(panelBotones, gbc);

        // ===== PANEL DE TAREAS =====
        gbc.gridy = 4;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        add(new JScrollPane(panelTareas), gbc);

        // ===== EVENTOS =====
        btnContinuar.addActionListener(e -> {
            String nombre = campoNombre.getText().trim();
            if (!nombre.isEmpty()) {
                Tarea tarea = new Tarea(nombre);
                tarea.agregarObservador(notificador);
                gestor.agregarTarea(tarea);
                campoNombre.setText("");
                new VentanaDetalleTarea(this, tarea).setVisible(true);
                this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, ingresa un nombre válido para la tarea.");
            }
        });

        btnPorPrioridad.addActionListener(e -> aplicarFiltro(new OrdenarPorPrioridad(), btnPorPrioridad));
        btnPorFecha.addActionListener(e -> aplicarFiltro(new OrdenarPorFecha(), btnPorFecha));
        btnPorEstado.addActionListener(e -> aplicarFiltro(new OrdenarPorEstado(), btnPorEstado));

        actualizarPanelTareas();
    }

    private void aplicarFiltro(EstrategiaOrdenamiento estrategia, JButton botonSeleccionado) {
        gestor.setEstrategia(estrategia);
        gestor.ordenarTareas();
        actualizarPanelTareas();

        for (JButton btn : botonesFiltro) {
            btn.setBackground(null);
            btn.setForeground(Color.BLACK);
        }

        botonSeleccionado.setBackground(Color.BLACK);
        botonSeleccionado.setForeground(Color.WHITE);
        botonActivo = botonSeleccionado;
    }

    public void actualizarPanelTareas() {
        panelTareas.removeAll();

        List<Tarea> tareas = gestor.getTareas();
        for (Tarea t : tareas) {
            JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
            fila.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            fila.setBackground(Color.WHITE);

            JLabel info = new JLabel(t.toString());
            fila.add(info);

            JComboBox<String> comboEstado = new JComboBox<>(new String[]{"Por hacer", "En progreso", "Terminada"});
            comboEstado.setSelectedItem(t.getEstado());
            comboEstado.addActionListener(e -> {
                String nuevoEstado = (String) comboEstado.getSelectedItem();
                t.setEstado(nuevoEstado);
                actualizarPanelTareas();
            });

            JButton btnEliminar = new JButton("Eliminar Tarea");
            btnEliminar.addActionListener(e -> {
                gestor.getTareas().remove(t);
                actualizarPanelTareas();
                notificador.notificar("La tarea '" + t.getNombre() + "' se ha eliminado.");
            });

            fila.add(new JLabel("Estado:"));
            fila.add(comboEstado);
            fila.add(btnEliminar);

            panelTareas.add(fila);
        }

        panelTareas.revalidate();
        panelTareas.repaint();
    }
}
