import java.util.*;

// Interfaz Estrategia
public interface EstrategiaOrdenamiento {
    void ordenar(List<Tarea> tareas);
}