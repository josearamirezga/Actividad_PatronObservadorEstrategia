import java.util.*;

public class OrdenarPorEstado implements EstrategiaOrdenamiento {
    @Override
    public void ordenar(List<Tarea> tareas) {
        tareas.sort(Comparator.comparingInt(t -> {
            return switch (t.getEstado()) {
                case "En progreso" -> 0;
                case "Por hacer" -> 1;
                case "Terminada" -> 2;
                default -> 3;
            };
        }));
    }
}
