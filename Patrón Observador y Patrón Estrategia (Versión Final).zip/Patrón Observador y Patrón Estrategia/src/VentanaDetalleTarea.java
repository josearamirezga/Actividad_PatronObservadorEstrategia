import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
import java.util.Date;

/**
 * Ventana para asignar detalles adicionales a una tarea:
 * prioridad y fecha de entrega.
 */
public class VentanaDetalleTarea extends JFrame {
    // Componentes de prioridad y fecha
    private JCheckBox baja, media, alta;
    private JComboBox<Integer> diaBox, anioBox;
    private JComboBox<String> mesBox;
    private JButton btnAgregar, btnVolver;
    
    // Referencia a la tarea y ventana principal
    private Tarea tarea;
    private VentanaPrincipal ventanaAnterior;

    /**
     * Constructor: inicializa la ventana con componentes de prioridad y fecha.
     */
    public VentanaDetalleTarea(VentanaPrincipal vp, Tarea tarea) {
        super("Detalle de Tarea");
        this.ventanaAnterior = vp;
        this.tarea = tarea;

        setSize(400, 300);
        setLayout(new GridBagLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        //  Sección de Prioridad 
        baja = new JCheckBox("Baja");
        media = new JCheckBox("Media");
        alta = new JCheckBox("Alta");

        // Permite solo una checkbox seleccionada (exclusividad manual)
        ActionListener exclusividad = e -> {
            JCheckBox source = (JCheckBox) e.getSource();
            baja.setSelected(source == baja);
            media.setSelected(source == media);
            alta.setSelected(source == alta);
        };
        baja.addActionListener(exclusividad);
        media.addActionListener(exclusividad);
        alta.addActionListener(exclusividad);

        // Posicionar componentes de prioridad
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        add(new JLabel("Prioridad:"), gbc);
        gbc.gridy++;
        add(baja, gbc);
        gbc.gridy++;
        add(media, gbc);
        gbc.gridy++;
        add(alta, gbc);

        //  Sección de Fecha 
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(new JLabel("Fecha de entrega:"), gbc);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);

        // Día del mes (1-31)
        diaBox = new JComboBox<>();
        for (int d = 1; d <= 31; d++) diaBox.addItem(d);

        // Meses en español
        String[] meses = {
            "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
        };
        mesBox = new JComboBox<>(meses);

        // Rango de años (actual a 10 años adelante)
        anioBox = new JComboBox<>();
        for (int a = currentYear; a <= currentYear + 10; a++) anioBox.addItem(a);

        // Posicionar selectores de fecha
        gbc.gridy++;
        add(diaBox, gbc);
        gbc.gridy++;
        add(mesBox, gbc);
        gbc.gridy++;
        add(anioBox, gbc);

        // === Botones: Agregar y Volver ===
        btnAgregar = new JButton("Agregar");
        btnVolver = new JButton("Volver");

        gbc.gridy++;
        gbc.gridx = 0;
        add(btnVolver, gbc);
        gbc.gridx = 1;
        add(btnAgregar, gbc);

        // Evento: Agregar 
        btnAgregar.addActionListener(e -> {
            // Validar prioridad seleccionada
            int prioridad = baja.isSelected() ? 1 : media.isSelected() ? 2 : alta.isSelected() ? 3 : 0;
            if (prioridad == 0) {
                JOptionPane.showMessageDialog(this, "Selecciona una prioridad.");
                return;
            }

            // Obtener valores de fecha
            int dia = (int) diaBox.getSelectedItem();
            int mes = mesBox.getSelectedIndex(); // Índice del mes
            int anio = (int) anioBox.getSelectedItem();

            // Construir objeto Date desde los valores seleccionados
            Calendar fecha = Calendar.getInstance();
            fecha.set(anio, mes, dia);
            Date fechaFinal = fecha.getTime();

            // Asignar los valores a la tarea
            tarea.setPrioridad(prioridad);
            tarea.setFechaEntrega(fechaFinal);

            // Cerrar esta ventana y volver a la principal
            dispose();
            ventanaAnterior.setVisible(true);
            ventanaAnterior.actualizarPanelTareas();
        });

        // Evento: Volver sin guardar
        btnVolver.addActionListener(e -> {
            dispose();
            ventanaAnterior.setVisible(true);
        });
    }
}
