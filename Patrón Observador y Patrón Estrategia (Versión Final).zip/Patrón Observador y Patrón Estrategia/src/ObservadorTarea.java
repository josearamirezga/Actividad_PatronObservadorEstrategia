public interface ObservadorTarea {
    void notificar(String mensaje);
}
