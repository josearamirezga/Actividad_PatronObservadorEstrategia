import java.util.*;

public class OrdenarPorPrioridad implements EstrategiaOrdenamiento {
    @Override
    public void ordenar(List<Tarea> tareas) {
        tareas.sort(Comparator.comparingInt(t -> {
            return switch (t.getPrioridad()) {
                case 3 -> 0; // Alta
                case 2 -> 1; // Media
                case 1 -> 2; // Baja
                default -> 3;
            };
        }));
    }
}
